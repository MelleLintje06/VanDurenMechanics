<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content-wrap head">
        <div class="content-wrapper head_text">Contact</div>
    </div>

    <div class="content-wrap">
        <div class="content-wrapper">
            <div class="contact-form">
                <form action="<?php echo e(route('post_contact')); ?>" class="contact_form" method="POST">
                    <?php echo csrf_field(); ?>
                    <label><p>Naam</p></label>
                    <input type="text" name="c_name" placeholder="Uw naam"></input>
                    <label><p>Email</p></label>
                    <input type="email" name="c_email" placeholder="Uw email"></input>
                    <label><p>Onderwerp</p></label>
                    <input type="text" name="c_topic" placeholder="Uw onderwerp"></input>
                    <label><p>Bericht</p></label>
                    <textarea style="width: 100%; height: 200px;" name="c_message" placeholder="Uw bericht"></textarea>

                    <input type="submit" value="Versturen">
                </form>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ExamenTraining\VanDurenMetalica\resources\views/contact.blade.php ENDPATH**/ ?>