<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content-wrap head">
        <div class="content-wrapper head_text">Store</div>
    </div>

    <div class="content-wrap">
        <div class="content-wrapper flex-box" style="margin-left: 20px">
            <h2>Onze Producten</h2>
        </div>
    </div>
    <div class="content-wrap">
        <div class="content-wrapper flex-box">
            <div class="productgrid-3">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($product->productStatus !== 0 && $product->productQuantity > 0): ?>
                        <div class="product prodcat_<?php echo e($product->category_ID); ?>" id="prod_<?php echo e($product->productID); ?>">
                            <a class="productlink" href="<?php echo e(route('product_details', ['slug' => $product->productSlug])); ?>">
                                <img class="productimage unselectable" src="/media/<?php echo e($product->productImage); ?>" alt="<?php echo e($product->productName); ?>">
                                <div class="productname"><?php echo e($product->productName); ?></div>
                                <?php if($product->productSalesprice == null): ?>
                                    <div class="productprice">€<?php echo e($product->productPrice); ?></div>
                                <?php else: ?>
                                <div class="productprice"><span class="saleprice">€<?php echo e($product->productPrice); ?></span><span>€<?php echo e($product->productSalesprice); ?></span></div>
                                <?php endif; ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($category->categoryID === $product->category_ID): ?>
                                        <div class="productcat"><?php echo e($category->categoryName); ?></div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="productfilters">
                <h3>Filter(s):</h3>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($category->categoryStatus !== 0): ?>
                        <div class="flex-box productfilter" id="cat_<?php echo e($category->categoryID); ?>">
                            <input class="productfilter_item <?php echo e($category->categorySlug); ?>" type="checkbox" onclick="productfilter()" name="<?php echo e($category->categoryName); ?>" value="<?php echo e($category->categoryID); ?>">
                            <div class="categoryname"><?php echo e($category->categoryName); ?></div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="resetfilterdiv">
                    <button class="resetfilters" onclick="resetfilter()">Reset Filter(s)</button>
                </div>
            </div>
        <div>
    </div>
</div>
<p class="filtercat" style="display: none;"><?php echo e(request()->get('cat')); ?></p>
</div>
<?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<script>
    const GetItem = () => {
    var list = document.getElementsByTagName("p");
    for (let item of list) {
        document.querySelectorAll(`.productfilter_item`).forEach(filter => {
            filter.classList.forEach(classes => {
                if(classes === item.innerText) {
                    filter.checked = true;
                }
            })
        })
    }
    productfilter();
}

window.onload = GetItem();

</script>
<?php /**PATH C:\xampp\htdocs\ExamenTraining\VanDurenMetalica\resources\views/products/webshop.blade.php ENDPATH**/ ?>