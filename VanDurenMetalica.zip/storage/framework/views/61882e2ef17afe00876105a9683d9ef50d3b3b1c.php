<div class="content-wrap header">
    <div class="content-wrapper content-header">
        <a class="companyname unselectable" href="/">
            <h1>Van Duren Mechanics</h1>
        </a>
        <nav class="navigation">
            <ul class="navigationlist">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li><a href="<?php echo e(route('store')); ?>">Store</a></li>
                <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
            </ul>
        </nav>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ExamenTraining\VanDurenMetalica\resources\views/layouts/header.blade.php ENDPATH**/ ?>