<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Van Duren Mechanics')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <link rel="stylesheet" href="/styles.css">
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div>
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form action="/products/edit" enctype="multipart/form-data" method="POST">
                            <?php echo csrf_field(); ?>
                            <input class="input_files" type="hidden" name="p_id" value="<?php echo e($prod->productID); ?>">
                            <label><div>Productnaam</div>
                                <input class="input_files" onkeyup="createslug(this.value)" type="text" name="p_name" value="<?php echo e($prod->productName); ?>">
                                <input class="input_files" id="p_slug" type="hidden" name="p_slug" value="<?php echo e($prod->productSlug); ?>">
                            </label>
                            <label><div>Prijs</div>
                                <input class="input_files" type="text" name="p_price" value="<?php echo e($prod->productPrice); ?>">
                            </label>
                            <label><div>Sale Prijs</div>
                                <input class="input_files" type="text" name="p_saleprice" value="<?php echo e($prod->productSalesprice); ?>">
                            </label>
                            <label><div>Aantal</div>
                                <input class="input_files" type="number" name="p_quantity" value="<?php echo e($prod->productQuantity); ?>">
                            </label>
                            <label><div>Merk</div>
                                <input class="input_files" type="text" name="p_brand" value="<?php echo e($prod->productBrand); ?>">
                            </label>
                            <label><div>Korte Beschrijving (mag HTML bevatten)</div>
                                <textarea class="input_files" style="height: 200px;" id="p_sd" type="text" onkeyup="generatedescription()">
                                    <?php echo e($prod->productShortDescription); ?>

                                </textarea>
                                <input type="hidden" name="p_sd" id="p_sd2">
                            </label>
                            <label><div>Lange Beschrijving (mag HTML bevatten)</div>
                                <textarea class="input_files" style="height: 200px;" type="text" name="p_ld">
                                    <?php echo e($prod->productLongDescription); ?>

                                </textarea>
                            </label>
                            <label><div>Afbeelding</div>
                                <input class="input_files" type="file" accept="image/png, image/jpeg, image/jpg" name="p_img" value="../../media/<?php echo e($prod->productImage); ?>">
                            </label>
                            <label><div>Categorie</div>
                                <select class="input_files" name="p_cat">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cat->categoryID === $prod->category_ID): ?>
                                            <option selected value="<?php echo e($cat->categoryID); ?>"><?php echo e($cat->categoryName); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($cat->categoryID); ?>"><?php echo e($cat->categoryName); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                            <label><div>Gemaakt door</div>
                                <select class="input_files" name="p_mb">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user->id === $prod->createdBy): ?>
                                        <option selected value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                            <label><div>Status</div>
                                <select class="input_files" name="p_status">
                                    <option value="0">Concept</option>
                                    <?php if($prod->productStatus === 0): ?>
                                        <option value="1">Gepubliceerd</option>
                                    <?php else: ?>
                                        <option value="1" selected>Gepubliceerd</option>
                                    <?php endif; ?>

                                </select>
                            </label>

                            <label>
                                <input class="input_files" style="margin-top: 10px; border: 1px solid black; cursor: pointer;" type="submit" value="Publiceren">
                            </label>
                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<script>
    const createslug = (value) => {
        var text = value.toLowerCase();
        text = text.replace(/\s+/g, '-');
        document.getElementById('p_slug').value = text;
    }
    const generatedescription = () => {
        text = document.getElementById('p_sd').value.replace(/\s+/g, ' ');
        console.log(text);
    }
</script>
<?php /**PATH C:\xampp\htdocs\ExamenTraining\VanDurenMetalica\resources\views/products/edit.blade.php ENDPATH**/ ?>