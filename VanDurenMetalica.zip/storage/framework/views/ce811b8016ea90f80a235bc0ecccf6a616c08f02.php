<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://dutch-leaders.com/wp-content/uploads/2022/03/logo.jpg">
    <link rel="stylesheet" href="/styles.css">
    <script src="/script.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Van Duren</title>
</head>
<?php /**PATH C:\xampp\htdocs\ExamenTraining\VanDurenMetalica\resources\views/layouts/head.blade.php ENDPATH**/ ?>