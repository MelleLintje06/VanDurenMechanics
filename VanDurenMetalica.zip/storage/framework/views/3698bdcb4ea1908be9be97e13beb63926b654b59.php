<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Van Duren Mechanics')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div style="border-bottom: 1px solid black;">
                        <p>Naam: <?php echo e($m->formName); ?></p>
                        <p>Email: <a href="mailto:<?php echo e($m->formEmail); ?>"><?php echo e($m->formEmail); ?></a></p>
                        <p style="border-top: 1px solid black; height: 30px; padding-top: 5px">
                            Onderwerp: <span style="font-weight: bold;"><?php echo e($m->formTopic); ?></span>
                        </p>
                        </div>
                        <div style="margin-top: 10px;">
                            <p>Bericht:</p>
                            <p><?php echo e($m->formMessage); ?></p>
                        </div>

                        <form action="/messages" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="c_id" value="<?php echo e($m->formID); ?>">
                            <input type="submit" style="margin-top: 30px; border: 3px solid black; padding: 10px; cursor: pointer;" value="Terug naar berichten">
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ExamenTraining\VanDurenMetalica\resources\views/message.blade.php ENDPATH**/ ?>