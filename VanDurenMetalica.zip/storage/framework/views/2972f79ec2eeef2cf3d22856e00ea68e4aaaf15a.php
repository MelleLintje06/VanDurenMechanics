<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="content-wrap head">
        <div class="content-wrapper head_text"><?php echo e($prod->productName); ?></div>
    </div>
    <div class="content-wrap">
        <div class="content-wrapper flex-box">
            <span class="breadcrum">
                <a href="/">Home</a>
                 »
                <a href="/store">Store</a>
                 »
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($category->categoryID == $prod->productID): ?>
                        <a href="/store?cat=<?php echo e($category->categorySlug); ?>"><?php echo e($category->categoryName); ?></a> »
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($prod->productName); ?>

            </span>
        </div>
    </div>
    <div class="content-wrap">
        <div class="content-wrapper flex-box">
            <div class="productdetails">
                <img class="productimg" src="/media/<?php echo e($prod->productImage); ?>">
            </div>
            <div class="productdetails">
                <h2><?php echo e($prod->productName); ?></h2>
                <?php echo $prod->productShortDescription; ?>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($category->categoryID == $prod->productID): ?>
                        <p><?php echo e($category->categoryName); ?></p>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($prod->productSalesprice == null): ?>
                    <div style="text-align: left;" class="productprice"><h3>€<?php echo e($prod->productPrice); ?></h3></div>
                <?php else: ?>
                    <div style="text-align: left;" class="productprice"><h3><span class="saleprice">€<?php echo e($prod->productPrice); ?></span><span>€<?php echo e($prod->productSalesprice); ?></span></h3></div>
                <?php endif; ?>

                <div class="tab">
                    <button class="tablinks active" onclick="tabs(event, 'Lange_Beschrijving')">Beschrijving</button>
                    <button class="tablinks" onclick="tabs(event, 'Eigenschappen')">Eigenschappen</button>
                    <button class="tablinks" onclick="tabs(event, 'Beoordelingen')">Beoordelingen</button>
                  </div>

                  <div id="Lange_Beschrijving" class="tabcontent" style="display: block">
                    <p><?php echo $prod->productLongDescription; ?></p>
                  </div>

                  <div id="Eigenschappen" class="tabcontent">
                    <table class="property_table">
                        <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($prop->productID === $prod->productID): ?>
                                <?php if($prop->color !== null): ?>
                                    <tr class="property_row">
                                        <td class="property">Kleur</td>
                                        <td class="property"><?php echo e($prop->color); ?></td>
                                    </tr>
                                <?php endif; ?>
                                <?php if($prop->type !== null): ?>
                                    <tr class="property_row">
                                        <td class="property">Type</td>
                                        <td class="property"><?php echo e($prop->type); ?></td>
                                    </tr>
                                <?php endif; ?>
                                <?php if($prop->material !== null): ?>
                                    <tr class="property_row">
                                        <td class="property">Materiaal</td>
                                        <td class="property"><?php echo e($prop->material); ?></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                  </div>

                  <div id="Beoordelingen" class="tabcontent">
                    <p style="display: none"><?php echo e($i = 1); ?></p>
                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($review->productID === $prod->productID && $i <= 5): ?>
                            <div class="review">
                                <div class="star_review">
                                    <?php for($x = 1; $x <= 5; $x++): ?>
                                    <?php if($x <= $review->starRating): ?>
                                        <s style="text-decoration: none;"></s>
                                    <?php else: ?>
                                        <s style="color:black; text-decoration: none;"></s>
                                    <?php endif; ?>

                                    <?php endfor; ?>
                                </div>
                                <span><?php echo e($review->reviewMessage); ?></span>
                                <p style="display: none"><?php echo e($i++); ?></p>
                            </div>
                        <?php elseif($review->productID === $prod->productID && $i == 6): ?>
                            <p>Lees meer reviews</p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
                    <form action="<?php echo e(route('post_review')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="p_id" value="<?php echo e($prod->productID); ?>">
                        <input type="hidden" name="p_slug" value="<?php echo e($prod->productSlug); ?>">
                        <div class="star-rating">
                            <p>Je waardering *</p>
                            <s><s><s><s><s></s></s></s></s></s>
                        </div>
                        <input name="review_star_rating" type="hidden" id="stars">
                        <p>Je beoordeling *</p>
                        <textarea name="review_message" style="width: 100%; height: 200px"></textarea>
                        <input type="submit" value="Versturen">
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<script>
    const tabs = (evt, item) => {
      var i, tabcontent, tablinks;
      tabcontent = document.getElementsByClassName("tabcontent");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
      }
      document.getElementById(item).style.display = "block";
      evt.currentTarget.className += " active";
    }

    $(function() {
            $("div.star-rating > s, div.star-rating-rtl > s").on("click", function(e) {

            // remove all active classes first, needed if user clicks multiple times
            $(this).closest('div').find('.active').removeClass('active');

            $(e.target).parentsUntil("div").addClass('active'); // all elements up from the clicked one excluding self
            $(e.target).addClass('active');  // the element user has clicked on


                var numStars = $(e.target).parentsUntil("div").length+1;
                // $('.show-result').text(numStars + (numStars == 1 ? " star" : " stars!"));
                document.getElementById('stars').value = numStars;
            });
        });
</script>
<?php /**PATH C:\xampp\htdocs\ExamenTraining\VanDurenMetalica\resources\views/products/product.blade.php ENDPATH**/ ?>