<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Van Duren Mechanics')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <link rel="stylesheet" href="/styles.css">
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div id="GA_Chart" style="width:100%; height: 400px;"></div>
                    <div id="P_Chart" style="width:100%; height: 400px;"></div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<script>
    google.charts.load('current',{packages:['corechart']});
    google.charts.setOnLoadCallback(GA_Chart);

    function GA_Chart() {
        // Set Data
        var data = google.visualization.arrayToDataTable([
            ['Datum', 'Bezoekers'],
            ['05-03-22',7],
            ['06-03-22',8],
            ['07-03-22',8],
            ['08-03-22',9],
            ['09-03-22',9],
            ['10-03-22',9],
            ['11-03-22',10],
            ['12-03-22',11],
            ['13-03-22',14],
            ['14-03-22',14],
            ['15-03-22',15]
        ]);
        // Set Options
        var options = {
            title: 'Google Analytics',
            hAxis: {title: 'Datum'},
            vAxis: {title: 'Bezoekers'},
            legend: 'none'
        };
        // Draw
        var chart = new google.visualization.LineChart(document.getElementById('GA_Chart'));
        chart.draw(data, options);
    }

    google.charts.setOnLoadCallback(P_Chart);
    function P_Chart() {
        // Set Data
        var data = google.visualization.arrayToDataTable([
            ['Datum', 'Bezoekers'],
            ['05-03-22',3],
            ['06-03-22',6],
            ['07-03-22',7],
            ['08-03-22',7],
            ['09-03-22',6],
            ['10-03-22',8],
            ['11-03-22',10],
            ['12-03-22',11],
            ['13-03-22',14],
            ['14-03-22',13],
            ['15-03-22',12]
        ]);
        // Set Options
        var options = {
            title: 'Producten bezocht',
            hAxis: {title: 'Datum'},
            vAxis: {title: 'Bezoekers'},
            legend: 'none'
        };
        // Draw
        var chart = new google.visualization.LineChart(document.getElementById('P_Chart'));
        chart.draw(data, options);
    }
</script>
<?php /**PATH C:\xampp\htdocs\ExamenTraining\VanDurenMetalica\resources\views/dashboard.blade.php ENDPATH**/ ?>