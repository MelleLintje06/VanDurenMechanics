<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/media/logo.jpg">
    <link rel="stylesheet" href="/styles.css">
    <script src="/script.js"></script>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Van Duren</title>
</head>
<body>
    <?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="content-wrap head">
        <div class="content-wrapper head_text"><?php echo e($prod->productName); ?></div>
    </div>
    <div class="content-wrap">
        <div class="content-wrapper flex-box">
            <span class="breadcrum">
                <a href="/">Home</a>
                 »
                <a href="/store">Store</a>
                 »
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($category->categoryID == $prod->productID): ?>
                        <a href="/store?cat=<?php echo e($category->categorySlug); ?>"><?php echo e($category->categoryName); ?></a> »
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($prod->productName); ?>

            </span>
        </div>
    </div>
    <div class="content-wrap">
        <div class="content-wrapper flex-box">
            <div class="productdetails">
                <img class="productimg" src="/media/<?php echo e($prod->productImage); ?>">
            </div>
            <div class="productdetails">
                <h2><?php echo e($prod->productName); ?></h2>
                <?php echo $prod->productShortDescription; ?>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($category->categoryID == $prod->productID): ?>
                        <p><?php echo e($category->categoryName); ?></p>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($prod->productSalesprice == null): ?>
                    <div style="text-align: left;" class="productprice"><h3>€<?php echo e($prod->productPrice); ?></h3></div>
                <?php else: ?>
                    <div style="text-align: left;" class="productprice"><h3><span class="saleprice">€<?php echo e($prod->productPrice); ?></span><span>€<?php echo e($prod->productSalesprice); ?></span></h3></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="content-wrap">
        <div class="content-wrapper flex-box">
            <?php echo $prod->productLongDescription; ?>

        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ExamenTraining\VanDurenMetalica\resources\views/product.blade.php ENDPATH**/ ?>