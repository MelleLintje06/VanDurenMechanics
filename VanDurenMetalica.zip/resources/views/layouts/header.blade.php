<div class="content-wrap header">
    <div class="content-wrapper content-header">
        <a class="companyname unselectable" href="/">
            <h1>Van Duren Mechanics</h1>
        </a>
        <nav class="navigation">
            <ul class="navigationlist">
                <li><a href="{{ route('home') }}">Home</a></li>
                <li><a href="{{ route('store') }}">Store</a></li>
                <li><a href="{{ route('contact') }}">Contact</a></li>
                <li><a href="{{ route('login') }}">Login</a></li>
            </ul>
        </nav>
    </div>
</div>
