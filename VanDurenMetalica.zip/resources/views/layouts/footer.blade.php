<div class="content-wrap footer">
    <div class="content-wrapper flex-box footer-wrap">
        <div class="footerwidget_1">
            <a class="companyname unselectable" href="/">
                <h1>Van Duren Mechanics</h1>
            </a>
        </div>
        <div class="footerwidget_2">
            <ul class="navigationlist footerlist_1">
                <li><a href="/">Home</a></li>
                <li><a href="/store">Store</a></li>
                <li><a href="/contact">Contact</a></li>
                <li><a href="/login">Login</a></li>
            </ul>
        </div>
        <div class="footerwidget_2">
            <ul class="navigationlist footerlist_2">
                <li>Tel: 06-123456</li>
                <li>Mail: info@vanduren.nl</li>
                <li>De Pinckart 66</li>
                <li>Nuenen</li>
            </ul>
        </div>
    </div>
</div>